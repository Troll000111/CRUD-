<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Collaborateur</title>
</head>
<body>
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><h1>Liste des collaborateurs</h1></div>

                    <div class="card-body">
                        <ul>
                            <?php
                                 $collaborateurs = \App\Models\Collaborateur::orderBy('Nom')->get();
                            ?>
                            <?php $__currentLoopData = $collaborateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collaborateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($collaborateur->Nom); ?></li>
                                <a href="<?php echo e(route('collaborateurs.edit', $collaborateur->id)); ?>">Modifier</a>
                                <form action="<?php echo e(route('collaborateurs.destroy', $collaborateur)); ?>" method="POST" id="form-delete-<?php echo e($collaborateur->id); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer <?php echo e($collaborateur->Nom); ?> ?')">Supprimer</button>
                                </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div><a href="<?php echo e(route('collaborateurs.create')); ?>">Créer un collaborateur</a></div>
    <div><a href="<?php echo e(route('acceuil.test')); ?>" class="btn btn-secondary">Retour</a></div>
</body>
</html><?php /**PATH D:\XAMP\htdocs\MASP\resources\views/liste.blade.php ENDPATH**/ ?>