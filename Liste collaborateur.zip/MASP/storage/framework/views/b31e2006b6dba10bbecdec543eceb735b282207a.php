<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modification</title>
</head>
<body>
<h1>Modifier un collaborateur</h1>
    <!--<form method="POST" action="<?php echo e(route('collaborateurs.update', $collaborateur->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="nom">Nom</label>
            <input type="text" class="form-control" id="nom" name="nom" value="<?php echo e($collaborateur->Nom); ?>">
        </div>
        <button type="submit" class="btn btn-primary">Modifier</button>
    </form>-->
    <form method="POST" action="<?php echo e(route('collaborateurs.update', $collaborateur->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <input type="hidden" name="id" value="<?php echo e($collaborateur->id); ?>">
    <label for="nom">Nom :</label>
    <input type="text" name="nom" value="<?php echo e($collaborateur->Nom); ?>"><br>
    <input type="submit" value="Modifier">
</form>
<a href="<?php echo e(route('collaborateurs.index')); ?>" class="btn btn-secondary">Retour</a>

</body>
</html><?php /**PATH D:\XAMP\htdocs\MASP\resources\views/edit.blade.php ENDPATH**/ ?>