<?php

use App\Http\Controllers\appController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CollaborateurController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/


Route::get('/', [appController::class, "test"])->name('acceuil.test');

Route::get('/collaborateurs', [CollaborateurController::class, 'index'])->name('collaborateurs.index');
Route::get('/collaborateurs/create', [CollaborateurController::class, 'create'])->name('collaborateurs.create');
Route::post('/collaborateurs', [CollaborateurController::class, 'store'])->name('collaborateurs.store');
Route::get('/collaborateurs/{id}', [CollaborateurController::class, 'show']);
Route::get('/collaborateurs/{id}/edit', [CollaborateurController::class, 'edit'])->name('collaborateurs.edit');
Route::put('/collaborateurs/{id}', [CollaborateurController::class, 'update'])->name('collaborateurs.update');
Route::delete('/collaborateurs/{collaborateur}', [CollaborateurController::class, 'destroy'])->name('collaborateurs.destroy');
Route::post('/collaborateurs/import', [CollaborateurController::class, 'import'])->name('collaborateurs.import');

