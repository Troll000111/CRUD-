<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/create.css">
    <script src="js/create.js"></script>
    <title>Creation</title>
    
</head>
<body>

<div class="form-container">

<!-- Formulaire d'ajout -->
  <form id="create-form" action="{{ route('collaborateurs.store') }}" method="POST">
    @csrf
    <label for="nom">Nom :</label>
    <input type="text" id="nom" name="nom"><br><br>
    <button type="submit">Ajouter</button>
  </form>


<!-- Importation fichier CSV -->  
  <form id="import-form" action="{{ route('collaborateurs.import') }}" method="POST" enctype="multipart/form-data">
    @csrf
    <div class="form-group">
      <label for="csv_file">Importer des noms à partir d'un fichier CSV</label>
      <input type="file" class="form-control-file" id="csv_file" name="csv_file">
    </div>
    <button type="submit" class="btn btn-primary">Importer</button>
  </form>

  <a href="{{ route('collaborateurs.index') }}" class="btn btn-secondary">Retour</a>
  
</div>


</body>
</html>