const createForm = document.getElementById('create-form');
const importForm = document.getElementById('import-form');
const createBtn = document.getElementById('create-form').querySelector('button[type="submit"]');
const importBtn = document.getElementById('import-form').querySelector('button[type="submit"]');

createBtn.addEventListener('click', () => {
    createForm.style.display = 'block';
    importForm.style.display = 'none';
});

importBtn.addEventListener('click', () => {
    createForm.style.display = 'none';
    importForm.style.display = 'block';
});