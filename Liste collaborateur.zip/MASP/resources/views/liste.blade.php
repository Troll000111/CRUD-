<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Collaborateur</title>
</head>
<body>
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><h1>Liste des collaborateurs</h1></div>

                    <div class="card-body">
                        <ul>
                            @php
                                 $collaborateurs = \App\Models\Collaborateur::orderBy('Nom')->get();
                            @endphp
                            @foreach ($collaborateurs as $collaborateur)
                                <li>{{ $collaborateur->Nom }}</li>
                                <a href="{{ route('collaborateurs.edit', $collaborateur->id) }}">Modifier</a>
                                <form action="{{ route('collaborateurs.destroy', $collaborateur) }}" method="POST" id="form-delete-{{ $collaborateur->id }}">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer {{ $collaborateur->Nom }} ?')">Supprimer</button>
                                </form>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div><a href="{{ route('collaborateurs.create') }}">Créer un collaborateur</a></div>
    <div><a href="{{ route('acceuil.test') }}" class="btn btn-secondary">Retour</a></div>
</body>
</html>