<?php

namespace App\Http\Controllers;

use App\Models\Collaborateur;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;



class CollaborateurController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        /*$collaborateurs = Collaborateur::all();
        return view('liste', ['collaborateurs' => $collaborateurs]);*/
        $collaborateurs = Collaborateur::orderBy('Nom')->get();
        /*$collaborateurs = DB::table('collaborateurs')->orderBy('created_at', 'desc')->get();*/
        return view('liste', compact('collaborateurs'));
        

    }




    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('create');
    }




    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'nom' => 'required',
        ]);
    
        $collaborateur = new Collaborateur();
        $collaborateur->Nom = $request->input('nom');
        $collaborateur->save();
    
        return redirect('/collaborateurs')->with('success', 'Collaborateur ajouté avec succès.');
    }
    



    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Collaborateur  $collaborateur
     * @return \Illuminate\Http\Response
     */   
     public function show(Collaborateur $collaborateur)
    {
        //
    }




    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Collaborateur  $collaborateur
     * @return \Illuminate\Http\Response
     */
   
   
     public function edit(Collaborateur $collaborateur,$id)
    {
         $collaborateur = Collaborateur::findOrFail($id);
         return view('edit', compact('collaborateur'));
    }




    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Collaborateur  $collaborateur
     * @return \Illuminate\Http\Response
     */   
     public function update(Request $request, $id)
     {
         $collaborateur = Collaborateur::findOrFail($id);
         $collaborateur->Nom = $request->input('nom');
         $collaborateur->save();
         return redirect()->route('collaborateurs.index');
     }
     



    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Collaborateur  $collaborateur
     * @return \Illuminate\Http\Response
     */
     public function destroy(Collaborateur $collaborateur)
    {
        $collaborateur->delete();
        return redirect()->route('collaborateurs.index');
    }


    

    public function import(Request $request)
   {
    $request->validate([
        'csv_file' => 'required|file|mimes:csv,txt',
    ]);

    $file = $request->file('csv_file');
    $csvData = file_get_contents($file);
    $rows = array_map('str_getcsv', explode("\n", $csvData));

    try {
        foreach ($rows as $row) {
            if (!empty($row[0])) {
                $collaborateur = new Collaborateur();
                $collaborateur->Nom = $row[0];
                $collaborateur->save();
            }
        }
    } catch(\Exception $e) {
        return redirect()->route('collaborateurs.create')->withErrors(['Une erreur s\'est produite lors de l\'importation des données. Veuillez réessayer.']);
    }

    return redirect()->route('collaborateurs.index')->with('success', 'Importation réussie !');
    }




    public function method_exists(Request $request)
    {
    // Vérifier si le formulaire d'importation de fichier CSV a été soumis
    if (!$request->has('csv_file')) {
        // Valider le formulaire de création
        $request->validate([
            'nom' => 'required|string|max:255',
        ]);

        // Créer un nouveau collaborateur avec les données soumises dans le formulaire de création
        $collaborateur = new Collaborateur();
        $collaborateur->Nom = $request->input('nom');
        $collaborateur->save();

        return redirect()->route('collaborateurs.index')->with('success', 'Collaborateur créé avec succès!');
    }

    // Si le formulaire d'importation de fichier CSV a été soumis, valider et importer le fichier CSV
    $request->validate([
        'csv_file' => 'required|file|mimes:csv,txt',
    ]);

    $file = $request->file('csv_file');
    $csvData = file_get_contents($file);
    $rows = array_map('str_getcsv', explode("\n", $csvData));

    foreach ($rows as $row) {
        if (!empty($row[0])) {
            $collaborateur = new Collaborateur();
            $collaborateur->Nom = $row[0];
            $collaborateur->save();
        }
    }

    return redirect()->route('collaborateurs.index')->with('success', 'Collaborateurs importés avec succès!');
    }
    


}
